import { useEffect, useState } from 'react'
import './App.css'
import axios from 'axios';

function App() {
  const [amount,setAmount] = useState(0);
  const [fromCurrency,setFromCurrency]=useState('USD');
  const [toCurrency,setToCurrency] = useState('INR');
  const [convertedAmount,setConvertedAmount] =useState(null);
  const [exchangerate ,setExchangerate] = useState(null);

  useEffect(()=>{
    const getExchange = async() =>{
      try{
        let url = `https://v6.exchangerate-api.com/v6/63fa844480354ca1691c287b/latest/${fromCurrency}`
        const res = await axios.get(url)
        console.log(res)
        setExchangerate(res.data.conversion_rates[toCurrency]);
      }catch(error){
     console.error('Error Exchsangin the data',error)
      }
    }
    getExchange();
  },[fromCurrency,toCurrency]);

useEffect(()=>{
if(exchangerate !== null){
  setConvertedAmount((amount * exchangerate).toFixed(2));
}
},[amount,exchangerate]);


  const handleAmountChange = (e) => {
    const value= parseFloat(e.target.value);
    setAmount(isNaN(value) ? 0 : value);
  }


  const fromAmountChange = (e) => {
    setFromCurrency(e.target.value);
  }


  const ToAmountChange = (e) => {
    setToCurrency(e.target.value);
  }

  return (
    <>
      <div className='currency-converter'>
        <div className="box"></div>
        <div className="data">
          <h1>currency converter</h1>
          <div className="input-container">
            <label htmlFor="amt">Amount</label>
            <input type="number" id='amt' onChange={handleAmountChange}/>
          </div>
          <div className="input-container">
            <label htmlFor="from-currency">From currency</label>
            <select name="" id="fromCurrency" value={fromCurrency} onChange={fromAmountChange}>
            <option value="USD">USD-United states dollar</option>
            <option value="EUR">EUR-Europe Euro</option>
            <option value="GBP">GBP-British Bound</option>
            <option value="JPY">JPY-Japanese Yen</option>
            <option value="AUD">AUD-Austratlian dollar</option>
            <option value="CAD">CAD -Canadian Dollar</option>
            <option value="CNY">CNY- Chinese Yuvan</option>
            <option value="INR">INR - Indian rupee</option>
            <option value="BRL">BRL-Brazilian Real</option>
            <option value="ZAR">ZAR - South Africa Rand</option>
            </select>
            
          
          </div>

          <div className="input-container">
            <label htmlFor="to-currency">TO currency</label>
            <select name="" id="toCurrency" value={toCurrency} onChange={ToAmountChange}>
            <option value="USD">USD-United states dollar</option>
            <option value="EUR">EUR-Europe Euro</option>
            <option value="GBP">GBP-British Bound</option>
            <option value="JPY">JPY-Japanese Yen</option>
            <option value="AUD">AUD-Austratlian dollar</option>
            <option value="CAD">CAD -Canadian Dollar</option>
            <option value="CNY">CNY- Chinese Yuvan</option>
            <option value="INR">INR - Indian rupee</option>
            <option value="BRL">BRL-Brazilian Real</option>
            <option value="ZAR">ZAR - South Africa Rand</option>
            </select>
          </div>
          <div className="result">
            <p> {amount} {fromCurrency} is equal to {convertedAmount} {toCurrency}</p>
          </div>
        </div>

      </div>



    </>
  )
}

export default App;
